# Test cases for myTurbulenceModels

**Notei:** tests are intended for validation / verification of turbulence models. The relaxation 
factors, tolerances neither schemes are not set to optimal values!


## Flat plate flows

* **T3A** - flat plate transitional flows without pressure gradient
